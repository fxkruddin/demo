'use client';

const features = [
  {
    icon: "ri-truck-line",
    title: "Free Delivery",
    description: "Complimentary white-glove delivery service for all orders over $1,000"
  },
  {
    icon: "ri-shield-check-line",
    title: "10-Year Warranty",
    description: "Comprehensive warranty coverage on all furniture pieces for your peace of mind"
  },
  {
    icon: "ri-palette-line",
    title: "Custom Design",
    description: "Personalize your furniture with our bespoke customization service"
  },
  {
    icon: "ri-customer-service-2-line",
    title: "Expert Support",
    description: "Dedicated design consultants to help you create your perfect space"
  }
];

export default function Features() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16 fade-in">
          <h2 className="text-3xl md:text-4xl font-light text-stone-800 mb-4" style={{fontFamily: 'Playfair Display, serif'}}>
            The LIVORA Experience
          </h2>
          <p className="text-stone-600 text-lg max-w-2xl mx-auto">
            We're committed to providing exceptional service and quality that exceeds your expectations.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="fade-in text-center group" style={{animationDelay: `${index * 0.1}s`}}>
              <div className="w-16 h-16 mx-auto mb-6 bg-stone-100 rounded-full flex items-center justify-center group-hover:bg-stone-800 transition-colors duration-300">
                <i className={`${feature.icon} text-2xl text-stone-700 group-hover:text-white transition-colors duration-300`}></i>
              </div>
              <h3 className="text-xl font-medium text-stone-800 mb-4">
                {feature.title}
              </h3>
              <p className="text-stone-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}