'use client';

import Link from 'next/link';

const bestSellers = [
  {
    id: 5,
    name: "Heritage Chesterfield Sofa",
    price: "$3,299",
    image: "https://readdy.ai/api/search-image?query=Classic%20Chesterfield%20sofa%20in%20rich%20brown%20leather%2C%20traditional%20button%20tufting%2C%20rolled%20arms%2C%20luxury%20vintage%20style%20furniture%2C%20premium%20leather%20upholstery%2C%20elegant%20living%20room%20centerpiece%2C%20warm%20brown%20tones%2C%20sophisticated%20design&width=800&height=600&seq=best001&orientation=landscape",
    category: "Living Room",
    rating: 5,
    reviews: 127
  },
  {
    id: 6,
    name: "Walnut Executive Desk",
    price: "$1,899",
    image: "https://readdy.ai/api/search-image?query=Beautiful%20walnut%20wood%20executive%20desk%2C%20modern%20office%20furniture%2C%20clean%20lines%2C%20rich%20dark%20wood%20grain%2C%20minimalist%20design%2C%20home%20office%20workspace%2C%20premium%20wooden%20desk%20with%20drawers%2C%20sophisticated%20business%20furniture&width=800&height=600&seq=best002&orientation=landscape",
    category: "Office",
    rating: 5,
    reviews: 89
  },
  {
    id: 7,
    name: "Cloud Comfort Sectional",
    price: "$4,199",
    image: "https://readdy.ai/api/search-image?query=Large%20comfortable%20sectional%20sofa%2C%20plush%20cream%20colored%20upholstery%2C%20modern%20L-shaped%20design%2C%20soft%20cushions%2C%20luxury%20family%20room%20furniture%2C%20neutral%20beige%20tones%2C%20cozy%20living%20room%20seating%2C%20contemporary%20style&width=800&height=600&seq=best003&orientation=landscape",
    category: "Living Room",
    rating: 5,
    reviews: 203
  }
];

export default function BestSellers() {
  return (
    <section className="py-20 bg-stone-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16 fade-in">
          <h2 className="text-3xl md:text-4xl font-light text-stone-800 mb-4" style={{fontFamily: 'Playfair Display, serif'}}>
            Best Sellers
          </h2>
          <p className="text-stone-600 text-lg max-w-2xl mx-auto">
            Our most loved pieces that have transformed countless homes with their timeless appeal.
          </p>
        </div>

        <div className="space-y-12">
          {bestSellers.map((product, index) => (
            <div key={product.id} className={`fade-in ${index % 2 === 0 ? '' : 'lg:flex-row-reverse'} flex flex-col lg:flex-row items-center gap-8 lg:gap-16`}>
              <div className="flex-1">
                <Link href={`/product/${product.id}`} className="group cursor-pointer">
                  <div className="relative overflow-hidden bg-white aspect-[4/3] product-hover">
                    <img 
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute top-4 left-4">
                      <span className="bg-amber-600 text-white text-xs font-medium px-2 py-1 whitespace-nowrap">
                        Best Seller
                      </span>
                    </div>
                  </div>
                </Link>
              </div>
              <div className="flex-1 space-y-6">
                <div>
                  <p className="text-sm text-stone-500 font-medium mb-2">{product.category}</p>
                  <h3 className="text-2xl md:text-3xl font-light text-stone-800 mb-4" style={{fontFamily: 'Playfair Display, serif'}}>
                    {product.name}
                  </h3>
                  <div className="flex items-center gap-2 mb-4">
                    <div className="flex space-x-1">
                      {[...Array(product.rating)].map((_, i) => (
                        <i key={i} className="ri-star-fill text-amber-400 w-4 h-4 flex items-center justify-center"></i>
                      ))}
                    </div>
                    <span className="text-sm text-stone-600">({product.reviews} reviews)</span>
                  </div>
                  <p className="text-stone-600 leading-relaxed mb-6">
                    Experience unparalleled comfort and style with this exceptional piece. Crafted with meticulous attention to detail and premium materials for lasting elegance.
                  </p>
                  <p className="text-2xl font-semibold text-stone-800 mb-6">{product.price}</p>
                </div>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Link 
                    href={`/product/${product.id}`}
                    className="inline-flex items-center justify-center px-8 py-3 bg-stone-800 text-white font-medium hover:bg-stone-900 transition-all duration-300 whitespace-nowrap cursor-pointer"
                  >
                    View Details
                  </Link>
                  <button className="inline-flex items-center justify-center px-8 py-3 border-2 border-stone-300 text-stone-700 font-medium hover:border-stone-800 hover:text-stone-800 transition-all duration-300 whitespace-nowrap cursor-pointer">
                    <i className="ri-heart-line mr-2 w-4 h-4 flex items-center justify-center"></i>
                    Add to Wishlist
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-16 fade-in">
          <Link 
            href="/shop" 
            className="inline-flex items-center px-8 py-3 border-2 border-stone-800 text-stone-800 font-medium hover:bg-stone-800 hover:text-white transition-all duration-300 whitespace-nowrap cursor-pointer"
          >
            Shop All Best Sellers
            <i className="ri-arrow-right-line ml-2 w-4 h-4 flex items-center justify-center"></i>
          </Link>
        </div>
      </div>
    </section>
  );
}
