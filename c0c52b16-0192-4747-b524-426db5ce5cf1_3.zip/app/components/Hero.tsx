
'use client';

import Link from 'next/link';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div 
        className="absolute inset-0 w-full h-full bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('https://readdy.ai/api/search-image?query=Luxury%20modern%20living%20room%20interior%20with%20elegant%20neutral%20furniture%2C%20cream%20colored%20sofa%2C%20walnut%20wood%20coffee%20table%2C%20minimalist%20design%2C%20warm%20natural%20lighting%2C%20sophisticated%20home%20decor%2C%20high-end%20residential%20space%20with%20clean%20lines%20and%20premium%20materials%2C%20beige%20and%20white%20color%20palette&width=1920&height=1080&seq=hero001&orientation=landscape')`
        }}
      >
        <div className="hero-overlay absolute inset-0"></div>
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center min-h-screen py-20">
          <div className="flex flex-col justify-center space-y-8">
            <div className="fade-in">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-light text-white leading-tight" style={{fontFamily: 'Playfair Display, serif'}}>
                Crafted for
                <span className="block font-medium">Modern Living</span>
              </h1>
            </div>
            
            <div className="fade-in">
              <p className="text-lg md:text-xl text-white/90 leading-relaxed max-w-lg">
                Discover our curated collection of premium furniture that transforms your space into a sanctuary of style and comfort.
              </p>
            </div>
            
            <div className="fade-in flex flex-col sm:flex-row gap-4">
              <Link 
                href="/shop" 
                className="inline-flex items-center justify-center px-8 py-4 bg-white text-stone-800 font-medium hover:bg-stone-100 transition-all duration-300 transform hover:scale-105 whitespace-nowrap cursor-pointer"
              >
                Explore Collection
                <i className="ri-arrow-right-line ml-2 w-4 h-4 flex items-center justify-center"></i>
              </Link>
              <Link 
                href="/about" 
                className="inline-flex items-center justify-center px-8 py-4 border-2 border-white text-white font-medium hover:bg-white hover:text-stone-800 transition-all duration-300 whitespace-nowrap cursor-pointer"
              >
                Our Story
              </Link>
            </div>
          </div>
          
          <div className="hidden lg:block"></div>
        </div>
      </div>
      
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <button className="w-8 h-8 flex items-center justify-center text-stone-600 hover:text-stone-800 transition-colors cursor-pointer">
          <i className="ri-arrow-down-line text-xl"></i>
        </button>
      </div>
    </section>
  );
}
