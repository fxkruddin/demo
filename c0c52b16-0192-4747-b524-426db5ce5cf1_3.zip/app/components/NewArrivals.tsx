'use client';

import Link from 'next/link';

const newArrivals = [
  {
    id: 1,
    name: "Milano Velvet Sofa",
    price: "$2,899",
    image: "https://readdy.ai/api/search-image?query=Elegant%20velvet%20sofa%20in%20soft%20cream%20color%2C%20modern%20contemporary%20design%2C%20tufted%20cushions%2C%20gold%20metal%20legs%2C%20luxury%20living%20room%20furniture%20piece%2C%20minimalist%20background%2C%20premium%20upholstery%20fabric%2C%20sophisticated%20home%20decor&width=600&height=600&seq=new001&orientation=squarish",
    category: "Living Room"
  },
  {
    id: 2,
    name: "Scandinavian Oak Dining Table",
    price: "$1,599",
    image: "https://readdy.ai/api/search-image?query=Beautiful%20oak%20wood%20dining%20table%2C%20Scandinavian%20minimalist%20design%2C%20natural%20wood%20grain%20texture%2C%20clean%20lines%2C%20modern%20rectangular%20shape%2C%20warm%20honey%20oak%20finish%2C%20simple%20elegant%20furniture%20piece%2C%20neutral%20background&width=600&height=600&seq=new002&orientation=squarish",
    category: "Dining"
  },
  {
    id: 3,
    name: "Marble Top Console",
    price: "$899",
    image: "https://readdy.ai/api/search-image?query=Luxury%20marble%20top%20console%20table%2C%20white%20marble%20surface%20with%20natural%20veining%2C%20black%20metal%20geometric%20base%2C%20modern%20entryway%20furniture%2C%20sophisticated%20design%2C%20premium%20materials%2C%20minimalist%20home%20decor%20accent%20piece&width=600&height=600&seq=new003&orientation=squarish",
    category: "Accent"
  },
  {
    id: 4,
    name: "Leather Lounge Chair",
    price: "$1,299",
    image: "https://readdy.ai/api/search-image?query=Premium%20leather%20lounge%20chair%2C%20cognac%20brown%20leather%20upholstery%2C%20mid-century%20modern%20design%2C%20wooden%20frame%2C%20comfortable%20armchair%2C%20luxury%20furniture%20piece%2C%20warm%20brown%20tones%2C%20sophisticated%20living%20room%20seating&width=600&height=600&seq=new004&orientation=squarish",
    category: "Seating"
  }
];

export default function NewArrivals() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16 fade-in">
          <h2 className="text-3xl md:text-4xl font-light text-stone-800 mb-4" style={{fontFamily: 'Playfair Display, serif'}}>
            New Arrivals
          </h2>
          <p className="text-stone-600 text-lg max-w-2xl mx-auto">
            Discover our latest curated pieces, carefully selected for their exceptional design and craftsmanship.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {newArrivals.map((product, index) => (
            <div key={product.id} className={`fade-in product-hover group cursor-pointer`} style={{animationDelay: `${index * 0.1}s`}}>
              <Link href={`/product/${product.id}`}>
                <div className="relative overflow-hidden bg-stone-50 aspect-square mb-4">
                  <img 
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="bg-stone-800 text-white text-xs font-medium px-2 py-1 whitespace-nowrap">
                      New
                    </span>
                  </div>
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all duration-300"></div>
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-stone-500 font-medium">{product.category}</p>
                  <h3 className="text-lg font-medium text-stone-800 group-hover:text-stone-600 transition-colors">
                    {product.name}
                  </h3>
                  <p className="text-stone-800 font-semibold">{product.price}</p>
                </div>
              </Link>
            </div>
          ))}
        </div>

        <div className="text-center mt-12 fade-in">
          <Link 
            href="/shop" 
            className="inline-flex items-center px-8 py-3 border-2 border-stone-800 text-stone-800 font-medium hover:bg-stone-800 hover:text-white transition-all duration-300 whitespace-nowrap cursor-pointer"
          >
            View All Products
            <i className="ri-arrow-right-line ml-2 w-4 h-4 flex items-center justify-center"></i>
          </Link>
        </div>
      </div>
    </section>
  );
}