'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'sticky-nav shadow-sm' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          <Link href="/" className="flex items-center">
            <span className="text-2xl lg:text-3xl font-bold text-stone-800" style={{fontFamily: 'var(--font-pacifico)'}}>
              LIVORA
            </span>
            <span className="ml-2 text-sm font-light text-stone-600 hidden sm:block">Home</span>
          </Link>

          <nav className="hidden lg:flex items-center space-x-8">
            <Link href="/" className="text-stone-700 hover:text-stone-900 font-medium transition-colors whitespace-nowrap">
              Home
            </Link>
            <Link href="/shop" className="text-stone-700 hover:text-stone-900 font-medium transition-colors whitespace-nowrap">
              Shop
            </Link>
            <Link href="/about" className="text-stone-700 hover:text-stone-900 font-medium transition-colors whitespace-nowrap">
              About Us
            </Link>
            <Link href="/contact" className="text-stone-700 hover:text-stone-900 font-medium transition-colors whitespace-nowrap">
              Contact
            </Link>
            <Link href="/blog" className="text-stone-700 hover:text-stone-900 font-medium transition-colors whitespace-nowrap">
              Blog
            </Link>
          </nav>

          <div className="hidden lg:flex items-center space-x-4">
            <button className="w-6 h-6 flex items-center justify-center text-stone-700 hover:text-stone-900 transition-colors cursor-pointer">
              <i className="ri-search-line text-lg"></i>
            </button>
            <button className="w-6 h-6 flex items-center justify-center text-stone-700 hover:text-stone-900 transition-colors cursor-pointer">
              <i className="ri-heart-line text-lg"></i>
            </button>
            <button className="w-6 h-6 flex items-center justify-center text-stone-700 hover:text-stone-900 transition-colors cursor-pointer">
              <i className="ri-shopping-bag-line text-lg"></i>
            </button>
          </div>

          <button 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden w-6 h-6 flex items-center justify-center text-stone-700 cursor-pointer"
          >
            <i className={`${isMobileMenuOpen ? 'ri-close-line' : 'ri-menu-line'} text-xl`}></i>
          </button>
        </div>

        {isMobileMenuOpen && (
          <div className="lg:hidden bg-white border-t border-stone-200">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <Link href="/" className="block px-3 py-2 text-stone-700 hover:text-stone-900 font-medium whitespace-nowrap">
                Home
              </Link>
              <Link href="/shop" className="block px-3 py-2 text-stone-700 hover:text-stone-900 font-medium whitespace-nowrap">
                Shop
              </Link>
              <Link href="/about" className="block px-3 py-2 text-stone-700 hover:text-stone-900 font-medium whitespace-nowrap">
                About Us
              </Link>
              <Link href="/contact" className="block px-3 py-2 text-stone-700 hover:text-stone-900 font-medium whitespace-nowrap">
                Contact
              </Link>
              <Link href="/blog" className="block px-3 py-2 text-stone-700 hover:text-stone-900 font-medium whitespace-nowrap">
                Blog
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}