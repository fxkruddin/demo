'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-stone-50 border-t border-stone-200">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          <div className="lg:col-span-1">
            <Link href="/" className="flex items-center mb-6">
              <span className="text-2xl font-bold text-stone-800" style={{fontFamily: 'var(--font-pacifico)'}}>
                LIVORA
              </span>
              <span className="ml-2 text-sm font-light text-stone-600">Home</span>
            </Link>
            <p className="text-stone-600 text-sm leading-relaxed mb-6">
              Curating exceptional furniture pieces that transform your living spaces into works of art. Quality craftsmanship meets timeless design.
            </p>
            <div className="flex space-x-4">
              <button className="w-8 h-8 flex items-center justify-center text-stone-600 hover:text-stone-800 transition-colors cursor-pointer">
                <i className="ri-facebook-fill text-lg"></i>
              </button>
              <button className="w-8 h-8 flex items-center justify-center text-stone-600 hover:text-stone-800 transition-colors cursor-pointer">
                <i className="ri-instagram-line text-lg"></i>
              </button>
              <button className="w-8 h-8 flex items-center justify-center text-stone-600 hover:text-stone-800 transition-colors cursor-pointer">
                <i className="ri-pinterest-line text-lg"></i>
              </button>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-stone-800 mb-4">Shop</h3>
            <ul className="space-y-3">
              <li><Link href="/shop?category=living-room" className="text-stone-600 hover:text-stone-800 text-sm transition-colors whitespace-nowrap">Living Room</Link></li>
              <li><Link href="/shop?category=bedroom" className="text-stone-600 hover:text-stone-800 text-sm transition-colors whitespace-nowrap">Bedroom</Link></li>
              <li><Link href="/shop?category=dining" className="text-stone-600 hover:text-stone-800 text-sm transition-colors whitespace-nowrap">Dining Room</Link></li>
              <li><Link href="/shop?category=office" className="text-stone-600 hover:text-stone-800 text-sm transition-colors whitespace-nowrap">Home Office</Link></li>
              <li><Link href="/shop?category=lighting" className="text-stone-600 hover:text-stone-800 text-sm transition-colors whitespace-nowrap">Lighting</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-stone-800 mb-4">Customer Care</h3>
            <ul className="space-y-3">
              <li><Link href="/contact" className="text-stone-600 hover:text-stone-800 text-sm transition-colors whitespace-nowrap">Contact Us</Link></li>
              <li><Link href="/shipping" className="text-stone-600 hover:text-stone-800 text-sm transition-colors whitespace-nowrap">Shipping Info</Link></li>
              <li><Link href="/returns" className="text-stone-600 hover:text-stone-800 text-sm transition-colors whitespace-nowrap">Returns</Link></li>
              <li><Link href="/care-guide" className="text-stone-600 hover:text-stone-800 text-sm transition-colors whitespace-nowrap">Care Guide</Link></li>
              <li><Link href="/warranty" className="text-stone-600 hover:text-stone-800 text-sm transition-colors whitespace-nowrap">Warranty</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-stone-800 mb-4">Newsletter</h3>
            <p className="text-stone-600 text-sm mb-4">
              Subscribe to receive updates on new arrivals and exclusive offers.
            </p>
            <div className="flex">
              <input 
                type="email" 
                placeholder="Enter your email" 
                className="flex-1 px-3 py-2 border border-stone-300 rounded-l-md focus:outline-none focus:border-stone-500 text-sm"
              />
              <button className="px-4 py-2 bg-stone-800 text-white rounded-r-md hover:bg-stone-900 transition-colors text-sm font-medium whitespace-nowrap cursor-pointer">
                Subscribe
              </button>
            </div>
          </div>
        </div>

        <div className="border-t border-stone-200 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-stone-600 text-sm">
            © 2024 LIVORA Home. All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <Link href="/privacy" className="text-stone-600 hover:text-stone-800 text-sm transition-colors whitespace-nowrap">
              Privacy Policy
            </Link>
            <Link href="/terms" className="text-stone-600 hover:text-stone-800 text-sm transition-colors whitespace-nowrap">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}